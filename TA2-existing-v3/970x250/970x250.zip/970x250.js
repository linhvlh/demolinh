(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.bg1 = function() {
	this.initialize(img.bg1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,700,250);


(lib.bg2 = function() {
	this.initialize(img.bg2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,780,250);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,143,110);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFEFE").s().p("AEeBFQgJgGAAgKQAAgIAEgFQAFgEAJgDQgJgEAAgGQAAgEADgCQAEgDAHgEQgQgGAAgQQAAgOAKgIQAHgFALAAIAMACIAXgBIAAAGIgQAAQAIAHAAANQAAAMgHAFQgDACgEACIgNADQgJADgEADQgDABAAADQAAABAAABQAAAAAAABQABAAAAAAQABABAAAAIANACIARACIAJADQALAGAAANQAAAMgLAGQgKAGgPAAQgQAAgKgHgAEmAoQgIAFAAAIQAAAGAHAEQAHAEAMAAQAQABAGgGQAFgEAAgGQAAgHgHgEQgHgEgNAAQgLAAgHADgAErgbQgGAGAAAIQAAAJAFAEQAFAFAIgBQAJABAFgFQAFgEAAgJQAAgHgFgGQgFgGgIAAQgIAAgFAFgAhjBFQgJgGAAgKQAAgIAEgFQAFgEAJgDQgJgEAAgGQAAgEADgCQAEgDAHgEQgQgGAAgQQAAgOAKgIQAHgFALAAIAMACIAXgBIAAAGIgQAAQAIAHAAANQAAAMgHAFQgDACgEACIgNADQgJADgEADQgDABAAADQAAABAAABQAAAAAAABQABAAAAAAQABABAAAAIANACIARACIAJADQALAGAAANQAAAMgLAGQgKAGgPAAQgQAAgKgHgAhbAoQgIAFAAAIQAAAGAHAEQAHAEAMAAQAQABAGgGQAFgEAAgGQAAgHgHgEQgHgEgNAAQgLAAgHADgAhWgbQgGAGAAAIQAAAJAFAEQAFAFAIgBQAJABAFgFQAFgEAAgJQAAgHgFgGQgFgGgIAAQgIAAgFAFgAGvBLIAAgIQALAAAEgFQADgDACgEIAGgOIgchPIAKAAIAXBDIAYhDIAJAAIgaBIIgIAVIgFAJQgIALgOAAIgDAAgABVBLIAAgIQALAAAFgFQADgDACgEIAFgOIgchPIAKAAIAXBDIAYhDIAJAAIgaBIIgHAVIgGAJQgIALgOAAIgDAAgAFuAlQgIgGAAgLQAAgSASgFQAMgEATgDIAAgFQAAgIgEgEQgEgFgKgBQgRABgCAOIgKAAQABgKAGgGQAIgGAOgBQAMAAAHAGQAFAEABAFQABAEAAANIAAAiQAAAKACAGIgIAAIgCgMQgIAOgQAAQgLAAgGgGgAF8ADQgNAFAAALQAAAIAEADQAFAFAHAAQANAAAHgKQAEgHAAgNIAAgJQgSAEgJADgAj/AlQgIgGAAgLQAAgSASgFQAMgEATgDIAAgFQAAgIgEgEQgEgFgKgBQgRABgCAOIgKAAQABgKAGgGQAIgGAOgBQAMAAAHAGQAFAEABAFQABAEAAANIAAAiQAAAKACAGIgIAAIgCgMQgIAOgQAAQgLAAgGgGgAjxADQgNAFAAALQAAAIAEADQAFAFAHAAQANAAAHgKQAEgHAAgNIAAgJQgSAEgJADgAD9ApIAAguIgBgNIgCgHQgDgHgMgBQgMAAgHAKQgEAHAAAMIAAAtIgJAAIAAg0IAAgSIgCgJIAJAAQABAEAAAIQAIgPARAAQAJAAAGAEQAGADACAHIACAIIAAAPIAAAtgAA+ApIgkgrIAjgkIALAAIgjAkIAlArgAARApIAAhxIAIAAIAABxgAiEApIAAguIgBgNIgCgHQgDgHgMgBQgMAAgHAKQgEAHAAAMIAAAtIgJAAIAAg0IAAgSIgCgJIAJAAQABAEAAAIQAIgPARAAQAJAAAGAEQAGADACAHIACAIIAAAPIAAAtgAloApIAAg3IgMAAIAAgIIAMAAIAAgxIAOAAIAXAAQAWADAMASQAJAPAAAUQAAAWgLAPQgNAQgUACIgXABgAlfAhIAIAAIASgBQAMgBAIgIQAPgNAAgZQAAgWgLgOQgJgJgOgCIgVgBIgGAAIAAApIAfAAIAAAIIgfAAgAnuAMIBBgbIhBgdIAAgJIBKAiIAAAIIhKAggAj2g7QgFgFgBgLIAGAAQACAGADAEQAEAEAFAAQAFAAAEgDQAEgFABgGIAGAAQAAAGgCAFQgFAMgNgBQgIABgGgHgABrg1IARgWIAOAAIgXAWg");
	this.shape.setTransform(37.275,7.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9F0002").s().p("ApxCWIAAkrITjAAIAAErg");
	this.shape_1.setTransform(38.375,7.225);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24.2,-7.7,125.2,29.9);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AATB0QgEgFAAgGQAAgGAEgFQAFgFAGAAQAHABAEAFQAFAEAAAGQAAAGgFAFQgEAEgHABQgGgBgFgEgAgUA7QgMgLAAgSQAAgcAegLQASgGAegFIAAgHQAAgOgFgGQgIgIgRAAQgZAAgEAXIgPAAQACgQAJgJQAMgLAWAAQAUAAALAJQAHAGACAHQACAIAAATIAAA5QAAAPAEAKIgOAAQgDgHAAgLQgNAWgaAAQgQAAgLgIgAADADQgVAIAAASQAAALAIAIQAHAGALAAQAVAAAKgQQAHgLAAgWIAAgOQgeAGgNAGgAhbA8QgHgGAAgOIADhdIgTAAIAAgMIATAAIABglIAOAAIgBAlIAgAAIAAAMIggAAIgCBFIAAAQQAAAOADADQAEAFAIAAQAJAAAKgFIAAAOQgKADgLAAQgPAAgGgGgABgA/IAAiAIAPAAIAACAgABehjQgDgDAAgFQAAgGADgDQAEgEAGAAQAEABAEADQADADAAAGQAAAEgDAEQgDAEgFAAQgGAAgEgEg");
	this.shape.setTransform(197.325,-46.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ACABtQgngmAAhHQAAhJArgmQAfgbAtAAQAqAAAZAYQAZAXACAtIgtAAQgHgwgqAAQgeAAgRAYQgSAaAAAsQAAArARAaQARAaAfAAQAvAAAFg8IAuAAQgDAmgMAWQgYAsg5AAQgxAAghgegAjoBpQglgmAAhDQAAhEAmglQAgghAyAAQAfAAAYANQAVAMALATQALATAAAcIgsAAQgGgvgvAAQgfAAgQAWQgUAaAAAuQAAAsATAaQARAZAhAAQAPAAAQgFQAPgFAMgIIAAgrIg2AAIAAglIBfAAIAABvQguAfgzAAQg3AAghgigAK0B1QgYgWAAgnIAtAAQAAASALALQAMAKAVAAQATAAAKgKQAMgLAAgSQAAgNgJgKQgHgJgPgDQgPgDgbAAIAAgnIAKAAQAbAAANgHQAIgFAFgIQAGgIAAgKQAAgOgJgIQgKgJgPAAQggAAgFAhIgrAAQABggATgUQAXgYArAAQAjAAAUARQAWAUAAAhQABAVgKAPQgLAOgVAIQAtAMABAxQAAAngcAXQgZAUglAAQgrAAgXgVgAIZCJIAAg5IhtAAIAAgoIBlioIA6AAIAACoIAuAAIAAAoIgtAAIAAA5gAHbAoIBBAAIAAhxgAlrCGIAAjQIg4DQIg1AAIg5jQIAADQIguAAIAAkLIBHAAIA6DUIA7jUIBIAAIAAELgAqZCGIgRg4IhfAAIgRA4Ig0AAIBbkLIAzAAIBcELgAr7AiIBEAAIgihsg");
	this.shape_1.setTransform(92,-54.525);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(7.3,-68.4,201.6,33.60000000000001);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AG0BpQgkgmAAhDQAAhDAmgmQAggiAzAAQAeABAYANQAVAMAKASQALAUACAcIgtAAQgGgwgvAAQgfAAgQAXQgUAaAAAuQAAAtASAZQASAZAhgBQAPABAPgFQAQgGALgHIAAgrIg2AAIAAgmIBgAAIAABwQguAfg0AAQg2AAgigigAVzCGIAAkLICpAAIAAAsIh1AAIAAA/IBqAAIAAArIhqAAIAABJIB5AAIAAAsgAR1CGIAAkLIBBAAQA5gBAbAOQAfAQARAiQAPAfAAAnQAAA3gdAmQgZAhgtAFQgTADglAAgASnBaIAZAAQAWAAAMgDQANgCAJgIQAPgKAJgaQAFgUABgVQAAgbgJgTQgHgVgQgKQgMgHgMgDQgMgCgeAAIgNAAgAQcCGIg3hnIglAAIAABnIgzAAIAAkLIBCAAQAjAAASACQARADAOAHQASAKALASQAKATAAAXQAAA0gwAWIA+BvgAPAgMIATAAQAeAAANgDQALgFAGgKQAGgIAAgNQAAgWgRgKQgIgEgKgBIgkgBIgOAAgAM4CGIgRg4IhfAAIgRA4Ig1AAIBbkLIA0AAIBcELgALWAiIBEAAIgjhsgAEHCGIAAjfIhHAAIAAgsIDDAAIAAAsIhIAAIAADfgABtCGIhvi8IAAC8IgxAAIAAkLIA2AAIBtC8IAAi8IAyAAIAAELgAiHCGIgRg4IhfAAIgRA4Ig0AAIBbkLIA0AAIBbELgAjpAiIBEAAIgihsgAnSCGIhbkLIA3AAIBADQIBAjQIA3AAIhdELgAplCGIgRg4IhfAAIgRA4Ig0AAIBbkLIAzAAIBdELgArHAiIBEAAIgihsgAwwCGIAAkLICoAAIAAAsIh1AAIAAA/IBqAAIAAArIhqAAIAABJIB6AAIAAAsgAygCGIAAh3IhqAAIAAB3IgzAAIAAkLIAzAAIAABrIBqAAIAAhrIA0AAIAAELgA3YCGIAAjfIhHAAIAAgsIDBAAIAAAsIhHAAIAADfg");
	this.shape.setTransform(158.35,60.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ANKCtIgbhNIhnAAIgaBNIgYAAIBdkOIARAAIBeEOgALOBMIBbAAIgtiMgAJSCtIAAiEIiFAAIAACEIgYAAIAAkLIAYAAIAAB0ICFAAIAAh0IAWAAIAAELgADnCtIAAkLIAnAAQA0AAAVAGQAXAIANAWQALARAAAZQgBAdgQAUQgRAVggAEQgSABgfAAIgUAAIAABygAD/AoIATAAQAjAAARgDQAngJgBgsQABgTgJgOQgIgOgOgFQgLgFgMgBIgrgBIgNAAgAAmCtIAAj3IhUD3IgWAAIhUj3IAAD3IgYAAIAAkLIAlAAIBSDxIBQjxIAlAAIAAELgAj0CtIgbhNIhnAAIgbBNIgXAAIBdkOIASAAIBcEOgAlvBMIBaAAIgtiMgAnsCtIAAiEIiFAAIAACEIgXAAIAAkLIAXAAIAAB0ICFAAIAAh0IAWAAIAAELgArRCtIh4iNIBxh+IAdAAIhyB+IB9CNgAthCtIAAkLIAYAAIAAELgALph5IA0gzIAiAAIg+AzgAlUh5IAzgzIAiAAIg+Azg");
	this.shape_1.setTransform(121.6,-28.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.6,-46.1,313.59999999999997,120.6);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bg2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,780,250);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ADzGVQgIgJAAgMQAAgMAIgIQAIgIAMAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgMAAgIgIgAL2E8QgjgiAAhAQAAgTAFgUQAFgTAIgOQAQgbAcgNQAWgKAZAAQArAAAeAcQAjAiAAA+QAAA+gjAiQgdAdgsAAQgtAAgdgdgAMVCbQgSAYAAAoQAAAqASAYQAPAUAcAAQAbAAAPgUQASgYAAgpQAAgpgSgYQgPgUgcAAQgbAAgPAUgADGFGQgWgRgGgfQgCgMAAgbIAAiLIAuAAIAACKQAAAdAEALQAFAOAMAHQAMAGAQAAQAmAAAIggQADgKAAgZIAAiKIAuAAIAACLQAAAagCAMQgCAMgFALQgMAYgaAMQgVAJgbAAQgnAAgagTgAH6FUIAAjwIA6AAQAzAAAYANQAcAOAPAeQAOAbAAAkQAAAxgaAjQgXAdgoAFQgRACghAAgAIoEtIAVAAQAUAAALgCQALgDAJgGQANgKAHgXQAGgRAAgUQAAgYgIgSQgHgSgNgJQgKgHgLgCQgMgCgbAAIgKAAgAAcFUIAAjIIg/AAIAAgoICsAAIAAAoIg/AAIAADIgAF/CgQAPgUACgUQgXgDAAgSQAAgKAHgHQAHgGAKAAQALAAAHAIQAIAJAAAOQAAAYgZAdgACaheQggghAAg8QAAg+AhgiQAdgdAtAAQAbAAAWAMQASAKAKARQAJARACAZIgoAAQgGgqgpAAQgcAAgOAUQgSAXAAArQAAAnAQAXQAPAWAfAAQANAAAOgEQANgFAKgHIAAgmIgwAAIAAgiIBWAAIAABjQgpAdgvAAQgwAAgegfgAioheQggghAAg8QAAg+AhgiQAdgdAtAAQAbAAAWAMQASAKAKARQAJARACAZIgoAAQgGgqgpAAQgcAAgOAUQgSAXAAArQAAAnAQAXQAPAWAfAAQANAAAOgEQANgFAKgHIAAgmIgwAAIAAgiIBWAAIAABjQgpAdgvAAQgwAAgegfgAMKhEIAAi7IgzC7IgwAAIgyi7IAAC7IgqAAIAAjwIBAAAIA0C/IA1i/IBAAAIAADwgAH6hEIgPgyIhVAAIgOAyIgwAAIBRjwIAvAAIBSDwgAGiidIA+AAIgfhigAkhhEIhlipIAACpIgrAAIAAjwIAxAAIBhCpIAAipIAsAAIAADwgApzhEIAAjwICXAAIAAAoIhpAAIAAA4IBfAAIAAAoIhfAAIAABBIBsAAIAAAngArchEIAAjwIAuAAIAADwgAtrhEIAAjIIhAAAIAAgoICtAAIAAAoIg/AAIAADIgAHalJIgZgcIgZAcIgqAAIAxgzIAkAAIAxAzgAoOlJIgagcIgZAcIgqAAIAxgzIAkAAIAVAWIAygxIA2AAIhJA7IgVAAIATATgAIAlhIhJg7IA2AAIA8A7g");
	this.shape.setTransform(46.025,75.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.9,34.6,187.9,82.5);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AwqUDMAAAgoFMAhWAAAMAAAAoFg");
	this.shape.setTransform(82.6,-11.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24.1,-139.4,213.5,256.6);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABtBdQgcghAAg7QAAhCAjghQAZgaAmAAQAnAAAWAaQANAQAEAZIgVAAQgLgwgvAAQgiAAgSAaQgXAeAAAxQAAA3AaAeQASAVAgABQAjAAARgeQAIgPACgVIAUAAQgCAfgOAUQgWAhgrAAQgsAAgbgggAjMBiQghgjABg/QAAg+AegiQAMgNARgGQASgJAWAAQAgAAATASQAVAQAEAhIgUAAQgGgXgKgKQgQgPgZAAQggAAgTAXQgZAdAAA1QAAA8AdAcQATASAgABQAdAAAcgQIAAhFIgxAAIAAgUIBFAAIAABjQggAYgtAAQguAAgYgbgAJTBeQgJgPAAgUIABgEIASAAQABAWAJAMQANARAcAAQAaAAAOgOQAOgPAAgXQgBgkgcgLQgLgEgPgBIgKABIAAgSIAKABQAQAAANgIQARgMAAgZQAAgQgKgMQgMgMgVAAQgnAAgHAtIgSAAQABgbAOgQQASgUAfAAQAiAAARAUQANAPAAAWQAAAlgjAQQAsAOAAAtQAAAhgUATQgUAUghAAQgsAAgTgegAHmB7IAAg+IhhAAIAAgPIBiiiIASAAIAACfIAqAAIAAASIgpAAIAAA+gAGaArIBNAAIAAiCgAk4B5IAAjfIhLDfIgUAAIhNjfIAADfIgUAAIAAjxIAiAAIBJDaIBJjaIAhAAIAADxgAo4B5IgYhFIhdAAIgYBFIgVAAIBTj0IARAAIBUD0gAqnAiIBRAAIgoh/g");
	this.shape.setTransform(79.15,45.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6.1,33.3,146.20000000000002,25);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol12("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(43.4,7.6,1,1,0,0,0,43.4,7.6);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},14,cjs.Ease.get(1)).wait(1951));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24.2,-7.7,125.2,29.9);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_6
	this.instance = new lib.Symbol10("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(51.4,186.45,1,1,0,0,0,120.6,10.7);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({_off:false},0).to({x:156.4,alpha:1},13,cjs.Ease.quadOut).wait(147).to({startPosition:0},0).to({_off:true},1).wait(4057));

	// Layer_4
	this.instance_1 = new lib.Symbol8("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(236,116.9,1,1,0,0,0,66.5,13.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(79).to({_off:false},0).to({x:128,alpha:1},13,cjs.Ease.quadOut).wait(147).to({startPosition:0},0).to({_off:true},1).wait(4057));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.9,0,546.6,178.1);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-4.95,392.9,1.5,1.5,0,0,0,150,299.9);
	this.instance.alpha = 0.2305;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:300,scaleX:1,scaleY:1,x:150,y:300,alpha:1},14,cjs.Ease.quadOut).wait(2492));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-229.9,-56.9,1170,375);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Symbol2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(180,22,1,1,0,0,0,92,51);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({_off:false},0).to({y:88,alpha:1},12,cjs.Ease.quadOut).to({_off:true},4282).wait(3));

	// Layer_3
	this.instance_1 = new lib.Symbol6("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(52.35,102.6,1,1,0,0,0,86.5,35.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({_off:false},0).to({x:174.85,alpha:1},12,cjs.Ease.quadOut).wait(4285));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AvdU9MAAAgp5Ie7AAMAAAAp5g");
	this.shape.setTransform(0.025,124.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4300));

	// Layer_1
	this.instance_2 = new lib.bg1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(80,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(4300));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-99,-9.3,879,268.2);


(lib.main = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_239 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(239).call(this.frame_239).wait(1));

	// cta
	this.instance = new lib.Symbol11("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(882.1,111.25,1.2,1.2,0,0,0,43.4,7.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(110).to({_off:false},0).wait(130));

	// logo
	this.instance_1 = new lib.Symbol4("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(876.5,193,1,1,0,0,0,73.5,57);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(240));

	// Layer_5
	this.instance_2 = new lib.Symbol5("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(62.6,63.6,1,1,0,0,0,62.6,63.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(240));

	// Layer_4
	this.instance_3 = new lib.Symbol3("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(150,300,1,1,0,0,0,150,300);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(79).to({_off:false},0).wait(161));

	// Layer_8
	this.instance_4 = new lib.Symbol1("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(240));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-229.9,-56.9,1222.3,375);


// stage content:
(lib._970x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.main();
	this.instance.parent = this;
	this.instance.setTransform(150,150,1,1,0,0,0,150,150);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(386,115.7,606.3,143.2);
// library properties:
lib.properties = {
	id: 'CC7D37763753984998DC0DE70763E649',
	width: 970,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg1.jpg?1692770829390", id:"bg1"},
		{src:"images/bg2.jpg?1692770829390", id:"bg2"},
		{src:"images/logo.jpg?1692770829390", id:"logo"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['CC7D37763753984998DC0DE70763E649'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;